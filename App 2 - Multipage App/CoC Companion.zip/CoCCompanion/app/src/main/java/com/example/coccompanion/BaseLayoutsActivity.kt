package com.example.coccompanion

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class BaseLayoutsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_base_layouts)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val baseLayouts = listOf(
            BaseLayout(
                "TH4 | Hybrid Base",
                R.drawable.base_th4,
                "https://link.clashofclans.com/en/?action=OpenLayout&id=TH4%3AHV%3AAAAAKgAAAAJkjRrxFjXI4nMPXXVvic-h"
            ),
            BaseLayout(
                "TH5 | Hybrid Base",
                R.drawable.base_th5,
                "https://link.clashofclans.com/en/?action=OpenLayout&id=TH5%3AHV%3AAAAAWQAAAAG6omlciHjoPGr46k5vDNpu"
            ),
            BaseLayout(
                "TH6 | Hybrid Base",
                R.drawable.base_th6,
                "https://link.clashofclans.com/en/?action=OpenLayout&id=TH6%3AHV%3AAAAAVAAAAAHOjxnk0EpTTGKk5362LFi4"
            )
            // Eventually add more bases!
        )

        recyclerView.adapter = BaseLayoutAdapter(baseLayouts)
    }
}

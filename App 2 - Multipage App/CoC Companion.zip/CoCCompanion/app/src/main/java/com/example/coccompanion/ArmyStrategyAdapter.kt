package com.example.coccompanion

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class ArmyStrategyAdapter(
    private val strategies: List<ArmyStrategy>
) : RecyclerView.Adapter<ArmyStrategyAdapter.ArmyViewHolder>() {

    inner class ArmyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardView: MaterialCardView = view.findViewById(R.id.cardArmyImage)
        val title: TextView = view.findViewById(R.id.tvStrategyTitle)
        val image: ImageView = view.findViewById(R.id.ivArmyImage)
        val copyButton: Button = view.findViewById(R.id.btnCopyLink)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArmyViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_army_strategy, parent, false)
        return ArmyViewHolder(view)
    }

    override fun onBindViewHolder(holder: ArmyViewHolder, position: Int) {
        val strategy = strategies[position]
        holder.title.text = strategy.title
        holder.image.setImageResource(strategy.imageResId)

        holder.copyButton.setOnClickListener {
            val clipboard = holder.itemView.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Army Link", strategy.copyLink)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(holder.itemView.context, "Army link copied!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int = strategies.size
}
package com.example.coccompanion

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class BaseLayoutAdapter(private val baseLayouts: List<BaseLayout>) :
    RecyclerView.Adapter<BaseLayoutAdapter.BaseLayoutViewHolder>() {

    class BaseLayoutViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTitle: TextView = itemView.findViewById(R.id.tvBaseLayoutTitle)
        val ivImage: ImageView = itemView.findViewById(R.id.ivBaseLayout)
        val btnCopyLink: Button = itemView.findViewById(R.id.btnCopyBaseLink)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseLayoutViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_base_layout, parent, false)
        return BaseLayoutViewHolder(view)
    }

    override fun onBindViewHolder(holder: BaseLayoutViewHolder, position: Int) {
        val baseLayout = baseLayouts[position]
        holder.tvTitle.text = baseLayout.title
        holder.ivImage.setImageResource(baseLayout.imageResId)

        holder.btnCopyLink.setOnClickListener {
            val clipboard =
                holder.itemView.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Base Layout Link", baseLayout.copyLink)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(holder.itemView.context, "Base layout link copied!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int = baseLayouts.size
}

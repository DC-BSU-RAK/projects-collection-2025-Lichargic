package com.example.coccompanion

data class ArmyStrategy(
    val title: String,
    val imageResId: Int,
    val copyLink: String
)
package com.example.coccompanion

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AttackStrategyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attack_strategy)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        recyclerView.addItemDecoration(VerticalSpaceItemDecoration(48))

        val strategies = listOf(
            ArmyStrategy(
                "TH3 | GIBARCH",
                R.drawable.army_th3,
                "https://link.clashofclans.com/en/?action=CopyArmy&army=i1x23u1x0-23x1-8x3-3x4-"
            ),
            ArmyStrategy(
                "TH4 | BALLOONS",
                R.drawable.army_th4,
                "https://link.clashofclans.com/en/?action=CopyArmy&army=i1x23-1x5u1x0-19x1-12x5-"
            ),
            ArmyStrategy(
                "TH5 | GIANT LOONS",
                R.drawable.army_th5,
                "https://link.clashofclans.com/en/?action=CopyArmy&army=i3x5u1x0-8x1-11x3-5x4-5x5-9x6-s2x0"
            )
            // Add more ArmyStrategy objects eventually!
        )

        recyclerView.adapter = ArmyStrategyAdapter(strategies)
    }
}

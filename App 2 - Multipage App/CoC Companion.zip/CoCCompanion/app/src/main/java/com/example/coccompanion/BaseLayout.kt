package com.example.coccompanion

data class BaseLayout(
    val title: String,
    val imageResId: Int,
    val copyLink: String
)

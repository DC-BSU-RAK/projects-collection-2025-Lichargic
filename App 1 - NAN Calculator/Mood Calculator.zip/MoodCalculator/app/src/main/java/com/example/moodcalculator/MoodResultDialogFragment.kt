package com.example.moodcalculator

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MoodResultDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_RESULTS_JSON = "results_json"

        fun newInstance(results: List<SubSubEmotionResult>): MoodResultDialogFragment {
            val fragment = MoodResultDialogFragment()
            val args = Bundle()
            args.putString(ARG_RESULTS_JSON, Gson().toJson(results))
            fragment.arguments = args
            return fragment
        }
    }

    private lateinit var results: List<SubSubEmotionResult>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dialog_mood_result, container, false)

        val json = arguments?.getString(ARG_RESULTS_JSON) ?: "[]"
        results = Gson().fromJson(json, object : TypeToken<List<SubSubEmotionResult>>() {}.type)

        val resultLayout = view.findViewById<LinearLayout>(R.id.resultContentLayout)
        resultLayout.removeAllViews()

        for (result in results) {
            val cardView = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.result_card_bg)
                setPadding(32, 32, 32, 32)
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.bottomMargin = 24
                layoutParams = params
            }

            val title = TextView(requireContext()).apply {
                text = result.name
                textSize = 18f
                setTextColor(resources.getColor(R.color.black, null))
                setPadding(0, 0, 0, 8)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val description = TextView(requireContext()).apply {
                text = result.description
                textSize = 16f
                setTextColor(resources.getColor(R.color.black, null))
                setLineSpacing(1.2f, 1.2f)
            }

            cardView.addView(title)
            cardView.addView(description)
            resultLayout.addView(cardView)
        }

        view.findViewById<Button>(R.id.closeButton).setOnClickListener {
            dismiss()
        }

        return view
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }
}

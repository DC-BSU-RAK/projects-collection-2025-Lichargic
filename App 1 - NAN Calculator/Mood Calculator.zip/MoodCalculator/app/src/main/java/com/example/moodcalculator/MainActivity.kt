package com.example.moodcalculator

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.InputStreamReader

data class SubSubEmotionResult(val name: String, val description: String)

class MainActivity : AppCompatActivity() {

    private lateinit var emotionWheel: EmotionWheel

    private lateinit var coreTopRow: LinearLayout
    private lateinit var coreBottomRow: LinearLayout
    private lateinit var subEmotionGrid: GridLayout

    private var selectedCore: CoreEmotion? = null
    private var selectedSub: SubEmotion? = null

    private lateinit var subSubDescriptions: Map<String, String>

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_MoodCalculator)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.decorView.setBackgroundResource(R.drawable.bg_gradient)

        coreTopRow = findViewById(R.id.coreTopRow)
        coreBottomRow = findViewById(R.id.coreBottomRow)
        subEmotionGrid = findViewById(R.id.subEmotionGrid)

        subSubDescriptions = loadSubSubDescriptions()

        emotionWheel = loadEmotionWheel() ?: run {
            Toast.makeText(this, "Failed to load emotions!", Toast.LENGTH_LONG).show()
            EmotionWheel(emptyList())
        }

        showCoreEmotionButtons()

        val calculateButton = findViewById<Button>(R.id.calculateButton)
        val infoButton = findViewById<Button>(R.id.infoButton)
        val resetButton = findViewById<Button>(R.id.resetButton)

        calculateButton.setOnClickListener {
            if (selectedCore == null || selectedSub == null) {
                Toast.makeText(this, "Just one more step—pick a core and sub emotion!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val results = selectedSub!!.subSubEmotions.map { subSub ->
                val desc = subSubDescriptions[subSub] ?: "No description available."
                SubSubEmotionResult(subSub, desc)
            }

            MoodResultDialogFragment.newInstance(results)
                .show(supportFragmentManager, "MoodResultDialog")
        }

        infoButton.setOnClickListener {
            Toast.makeText(this, "Tap Calculate when you're ready to see your mood outcome 💡", Toast.LENGTH_LONG).show()
        }

        resetButton.setOnClickListener {
            showCoreEmotionButtons()
            Toast.makeText(this, "Let's start fresh!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showCoreEmotionButtons() {
        coreTopRow.removeAllViews()
        coreBottomRow.removeAllViews()
        subEmotionGrid.removeAllViews()
        selectedCore = null
        selectedSub = null
        updateCalculateButtonState()

        val emotions = emotionWheel.emotions
        emotions.take(3).forEach { coreTopRow.addView(createCoreEmotionButton(it)) }
        emotions.drop(3).forEach { coreBottomRow.addView(createCoreEmotionButton(it)) }
    }

    private fun createCoreEmotionButton(core: CoreEmotion): Button = Button(this).apply {
        text = core.core
        background = ContextCompat.getDrawable(context, R.drawable.button_selector)
        textSize = 14f
        setPadding(8, 8, 8, 8)
        setTextColor(Color.BLACK)
        layoutParams = LinearLayout.LayoutParams(0, 120.toPx(), 1f).apply {
            val marginPx = 8.toPx()
            setMargins(marginPx, marginPx, marginPx, marginPx)
        }
        gravity = Gravity.CENTER
        isAllCaps = false
        alpha = 0.6f

        setOnClickListener {
            if (selectedCore == core) {
                selectedCore = null
                selectedSub = null
                highlightSelectedCoreButton(null)
                subEmotionGrid.removeAllViews()
            } else {
                selectedCore = core
                highlightSelectedCoreButton(this)
                showSubEmotionButtons(core)
            }
            updateCalculateButtonState()
        }
    }

    private fun highlightSelectedCoreButton(selectedButton: Button?) {
        val allCoreButtons = (0 until coreTopRow.childCount).map { coreTopRow.getChildAt(it) } +
                (0 until coreBottomRow.childCount).map { coreBottomRow.getChildAt(it) }

        allCoreButtons.forEach { view ->
            (view as? Button)?.alpha = if (view == selectedButton) 1.0f else 0.6f
        }
    }

    private fun showSubEmotionButtons(coreEmotion: CoreEmotion) {
        subEmotionGrid.removeAllViews()
        selectedSub = null
        updateCalculateButtonState()

        val subEmotions = coreEmotion.subEmotions
        val total = subEmotions.size
        subEmotionGrid.columnCount = 3

        subEmotions.forEachIndexed { index, sub ->
            val button = Button(this).apply {
                text = sub.name
                background = ContextCompat.getDrawable(context, R.drawable.button_selector)
                textSize = 13f
                setPadding(8, 8, 8, 8)
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
                isAllCaps = false
                alpha = 0.6f

                setOnClickListener {
                    if (selectedSub == sub) {
                        selectedSub = null
                        highlightSelectedButton(subEmotionGrid, null)
                    } else {
                        selectedSub = sub
                        highlightSelectedButton(subEmotionGrid, this)
                    }
                    updateCalculateButtonState()
                }
            }

            button.layoutParams = calculateSubEmotionLayoutParams(index, total)
            subEmotionGrid.addView(button)
        }
    }

    private fun calculateSubEmotionLayoutParams(index: Int, total: Int): GridLayout.LayoutParams {
        return GridLayout.LayoutParams().apply {
            height = 120.toPx()
            setMargins(8.toPx(), 8.toPx(), 8.toPx(), 8.toPx())

            val colIndex = index % 3

            width = 0
            columnSpec = GridLayout.spec(colIndex, 1f)

            val fullRows = total / 3
            val lastRowCount = total % 3

            if (index / 3 == fullRows) {
                when (lastRowCount) {
                    1 -> columnSpec = GridLayout.spec(0, 3, 1f)
                    2 -> {
                        columnSpec = when (colIndex) {
                            0 -> GridLayout.spec(0, 2, 1f)
                            1 -> GridLayout.spec(2, 1, 1f)
                            else -> columnSpec
                        }
                    }
                }
            }
        }
    }

    private fun highlightSelectedButton(grid: GridLayout, selectedButton: Button?) {
        for (i in 0 until grid.childCount) {
            val child = grid.getChildAt(i)
            (child as? Button)?.alpha = if (child == selectedButton) 1.0f else 0.6f
        }
    }

    private fun updateCalculateButtonState() {
        val calculateButton = findViewById<Button>(R.id.calculateButton)
        calculateButton.isEnabled = (selectedCore != null && selectedSub != null)
    }

    private fun Int.toPx(): Int = (this * resources.displayMetrics.density).toInt()

    private fun loadEmotionWheel(): EmotionWheel? = try {
        assets.open("emotions.json").use { inputStream ->
            InputStreamReader(inputStream).use { reader ->
                val rawJson: Map<String, Map<String, List<String>>> = Gson().fromJson(
                    reader,
                    object : TypeToken<Map<String, Map<String, List<String>>>>() {}.type
                )

                val emotions = rawJson.map { (core, subMap) ->
                    CoreEmotion(
                        core = core,
                        subEmotions = subMap.map { (subName, subSubs) ->
                            SubEmotion(name = subName, subSubEmotions = subSubs)
                        }
                    )
                }

                EmotionWheel(emotions)
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }

    private fun loadSubSubDescriptions(): Map<String, String> = try {
        assets.open("emotion_descriptions.json").use { inputStream ->
            InputStreamReader(inputStream).use { reader ->
                Gson().fromJson(reader, object : TypeToken<Map<String, String>>() {}.type)
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
        emptyMap()
    }
}

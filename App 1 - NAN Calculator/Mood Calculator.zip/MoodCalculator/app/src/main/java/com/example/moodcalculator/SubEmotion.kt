package com.example.moodcalculator

data class SubEmotion(
    val name: String,
    val subSubEmotions: List<String>
)

data class CoreEmotion(
    val core: String,
    val subEmotions: List<SubEmotion>
)

data class EmotionWheel(
    val emotions: List<CoreEmotion>
)